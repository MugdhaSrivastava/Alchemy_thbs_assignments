package Batch89;

public class Add {
	public int addTwoNum(int a, int b) {
		return a+b;
	}
	public boolean checkGreater(int a, int b) {
		if (a>b)
		{
			return true;
		}else {
			return false;
		}
	}
}
