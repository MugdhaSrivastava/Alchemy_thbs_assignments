package Batch89;
public class Calculator {
      int a, b;
      char ch;
      public int Calculate(int a, int b,char ch) {
      //System.out.println("Enter value of 1st number ::");
      this.a=a;
      //int a = sc.nextInt();
     // System.out.println("Enter value of 2nd number ::");
      this.b=b;
      //int b = sc.nextInt();  
      //System.out.println("Select operation");
     // System.out.println("Addition-a: Subtraction-s: Multiplication-m: Division-d: ");
      this.ch=ch;
      //char ch = sc.next().charAt(0);
      switch(ch) {
         case 'a' :
        	 return a+b;
        // System.out.println("Sum of the given two numbers: "+(a+b));
         //break;
         case 'b' :
        	 return a-b;
         //System.out.println("Difference between the two numbers: "+(a-b));
        // break;
         case 'c' :
        	 return a*b;
        	// break;
         //System.out.println("Product of the two numbers: "+(a*b));
         case 'd' :
        	 return (int)a/b;
         //System.out.println("Result of the division: "+(a/b));
         //break;
         default :
        	 return 0;
         //System.out.println("Invalid grade");
      }
   }
}