package Batch89;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class AddTest_T_F {
	Add a;
	@BeforeClass
	public static void testBefore() {
		System.out.println("It will execute before test case only once...!!");
	}
	@Before
	public void testB4() {
		a= new Add();
		System.out.println("Execute before each test case");
	}
	@After
	public void testAfter() {
		System.out.println("Execute After each test case");
	}
	@Test
	public void testAdd_F() {
		assertFalse("Condition should be false",a.checkGreater(100, 230));
	}
	@Test
	public void testAdd_T() {
		assertTrue("Condition should be True",a.checkGreater(100, 20));
	}
	@Test
	public void testAdd_Not() {
		assertNotEquals(false,a.checkGreater(14, 12));
	}
}
