package Batch89;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CalculatorTest {
	Calculator c;
	@Before
	public void TestBefore() {
		c=new Calculator();
	}
	@Test
	public void test_a() {
		assertEquals(100,c.Calculate(50, 50,'a'));
	}
	@Test
	public void test_b() {
		assertEquals(10,c.Calculate(50, 40,'b'));
	}
	@Test
	public void test_c() {
		assertEquals(100,c.Calculate(10, 10,'c'));
	}
	@Test
	public void test_d() {
		assertEquals(10,c.Calculate(100, 10,'d'));
	}
	@Test
	public void test_Not_a() {
		assertNotEquals("Expected result should not equal to actual result",100.0,c.Calculate(50, 50,'a'));
	}
	
}
