package Batch89;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class ArrayTest {
	 @Test
		public void testArrays() {
			int a[]= {1,2,3,4,5};
			int b[]= {5,3,2,4,1};
			Arrays.sort(b);
			assertArrayEquals(a,b);
		}
		  @Test(expected = ArithmeticException.class)
		    public void testException() {
		        int i = 5/0;
		    }
}
	/*
	
	
	@Test(timeout = 5)
	public void testProf() {
	    List<Integer> al = new ArrayList<Integer>();
	    for (int i =10000; i>0 ; i--) {
	        al.add(i);
	    }
	    int[] arr = al.stream().mapToInt(i -> i).toArray();
	    Arrays.sort(arr);
	}*/
