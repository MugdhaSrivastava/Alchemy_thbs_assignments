package Batch89;
import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.*;
public class AddTest {
	@Test
	public void test() {
		assertEquals("ABC","ABC");
	}
	@Test
	public void testAdd_10_20() {
		Add a = new Add();
		int ac=a.addTwoNum(10, 20);
		int ex=30;
		assertEquals(ac,ex);
	}
	@Test
	public void testAdd_22_12() {
		Add a = new Add();
		assertEquals(34,a.addTwoNum(22, 12));
	}

}
